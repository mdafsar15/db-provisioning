echo "************** installdb.sh start ********************";
if [ ! -f /usr/bin/mongod ]
    then
        if [ ! -f  /etc/apt/sources.list.d/mongodb-org-5.0.list ]
                then
                echo "creating mongodb repo file";
                wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -;
                echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/5.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-5.0.list;
    fi
        echo "****** Installing Mongodb *****";
        sudo apt-get update;
	sudo apt-get install -y mongodb-org;
	echo "mongodb-org hold" | sudo dpkg --set-selections;
	echo "mongodb-org-database hold" | sudo dpkg --set-selections;
	echo "mongodb-org-server hold" | sudo dpkg --set-selections;
	echo "mongodb-org-shell hold" | sudo dpkg --set-selections;
	echo "mongodb-org-mongos hold" | sudo dpkg --set-selections;
	echo "mongodb-org-tools hold" | sudo dpkg --set-selections;
	sudo systemctl disable mongod;
else
  echo "mongo db already installed.  Skipping...";
fi
echo "************** installdb.sh end ********************";
