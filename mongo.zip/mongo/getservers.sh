echo "************** getservers.sh start ********************";
sudo rm -f /tmp/execute.sh;
sudo rm -f /tmp/initiaterepl1.js;
sudo rm -f /tmp/initiaterepl2.js;
sudo rm -f /tmp/initiaterepl3.js;
sudo rm -f /tmp/showdbscript.js
sudo apt-get update -y;
sudo apt-get install -y sshpass;
echo "echo '\n\n########################################################'" >> /tmp/execute.sh;
echo "echo '******** MONGO DATABASE INSTALLATION PROCESS ***********';" >> /tmp/execute.sh;
echo "echo '########################################################\n\n'" >> /tmp/execute.sh;
while read HOST USER PWD;
  do echo $HOST;
  #sh /mongo/prepservers.sh $HOST;
  if [ ! -z "$HOST" ]
    then
    script0='" sudo apt-get update -y; sudo apt-get install -y sshpass;"';
    echo "sudo sh /tmp/ssh_ncb.sh $HOST $USER $PWD $script0;" >> /tmp/execute.sh;

    script11='"chmod 777 /tmp/uninstalldb.sh; sh /tmp/uninstalldb.sh mongo;"';
    echo "sudo sh /tmp/scp_ncb.sh $HOST $USER $PWD uninstalldb.sh;" >> /tmp/execute.sh;
    echo "sudo sh /tmp/ssh_ncb.sh $HOST $USER $PWD $script11;" >> /tmp/execute.sh;

    script1='"chmod 777 /tmp/installdb.sh; sh /tmp/installdb.sh;"';
    echo "sudo sh /tmp/scp_ncb.sh $HOST $USER $PWD installdb.sh;" >> /tmp/execute.sh;
    echo "sudo sh /tmp/ssh_ncb.sh $HOST $USER $PWD $script1;" >> /tmp/execute.sh;
    echo $preHOST;
    script2="chmod 777 /tmp/configdb.sh; sh /tmp/configdb.sh";
    echo "sudo sh /tmp/scp_ncb.sh $HOST $USER $PWD configdb.sh;" >> /tmp/execute.sh;
    echo "sudo sh /tmp/ssh_ncb.sh $HOST $USER $PWD " '"'$script2 $HOST $primHOST $primUSER $primPWD';"' >> /tmp/execute.sh;
    echo "primHOST  $prinHOST";
    if [ ! -z "$primHOST" ]
      then
        sh /tmp/initiaterepl.sh $HOST
    fi;
    if [ -z "$primHOST" ]
      then
        primHOST=$HOST;
	primUSER=$USER;
	primPWD=$PWD;
        sh /tmp/initiaterepl.sh;
    fi;
  fi;
  echo "$HOST Completed";
done < /tmp/servers.txt
echo "echo '\n \n########################################################'" >> /tmp/execute.sh;
echo "echo '******** MONGO DATABASE REPLICATION PROCESS ***********';" >> /tmp/execute.sh;
echo "echo '########################################################\n \n'" >> /tmp/execute.sh;
while read HOST1 USER1 PWD1;
  do echo $HOST1;
  if [ ! -z "$HOST1" ]
    then
    echo "sudo sh /tmp/scp_ncb.sh $HOST1 $USER1 $PWD1 startmongoinstance.sh;" >> /tmp/execute.sh;
    script1="chmod 777 /tmp/startmongoinstance.sh; sh /tmp/startmongoinstance.sh $HOST1 27017  ";
    echo "sudo sh /tmp/ssh_ncb.sh $HOST1 $USER1 $PWD1 "'"'$script1'"' >> /tmp/execute.sh;

  fi
done < /tmp/servers.txt
echo "use admin;" >> /tmp/initiaterepl3.js;
echo 'db.createUser({user: "aduser", pwd: "aduser",roles:[{role:"userAdminAnyDatabase", db:"admin"}, {role:"root", db:"admin"}]});' >> /tmp/initiaterepl3.js;

echo "sudo sh /tmp/scp_ncb.sh $primHOST $primUSER $primPWD initiaterepl2.js;" >> /tmp/execute.sh;
echo "sudo sh /tmp/scp_ncb.sh $primHOST $primUSER $primPWD initiaterepl3.js;" >> /tmp/execute.sh;

script4="chmod 777 /tmp/initiaterepl2.js; mongo --host $primHOST  < /tmp/initiaterepl2.js; rm -f /tmp/initiaterepl2.js";
echo "sudo sh /tmp/ssh_ncb.sh $primHOST $primUSER $primPWD "'"'$script4';"' >> /tmp/execute.sh;

script5="chmod 777 /tmp/initiaterepl3.js; mongo --host $primHOST  < /tmp/initiaterepl3.js; rm -f /tmp/initiaterepl3.js";
echo "sudo sh /tmp/ssh_ncb.sh $primHOST $primUSER $primPWD "'"'$script5';"' >> /tmp/execute.sh;

while read HOST1 USER1 PWD1;
  do echo $HOST1;
  if [ ! -z "$HOST1" ]
    then
    script1="sh /tmp/startmongoinstance.sh $HOST1 27017 Y";
    echo "sudo sh /tmp/ssh_ncb.sh $HOST1 $USER1 $PWD1 "'"'$script1'"' >> /tmp/execute.sh;
  fi
done < /tmp/servers.txt
while read HOST1 USER1 PWD1;
  do echo $HOST1;
  if [ ! -z "$HOST1" ]
    then
    script1='"rm -f /tmp/installdb.sh; rm -f /tmp/configdb.sh; rm -f /tmp/initiaterepl1.js; rm -f /tmp/startmongoinstance.sh;"';
    echo "sudo sh /tmp/ssh_ncb.sh $HOST1 $USER1 $PWD1 $script1;" >> /tmp/execute.sh;
  fi
done < /tmp/servers.txt
echo "echo '\n \n########################################################'" >> /tmp/execute.sh;
echo "echo '******** TESTING MONGO DATABASE  ***********';" >> /tmp/execute.sh;
echo "echo '########################################################\n \n'" >> /tmp/execute.sh;
echo "show dbs;" >> /tmp/showdbscript.js
echo "sudo sh /tmp/scp_ncb.sh $primHOST $primUSER $primPWD showdbscript.js;" >> /tmp/execute.sh;
script2="chmod 777 /tmp/showdbscript.js; mongo --host $primHOST -u aduser -p aduser -authenticationDatabase admin < /tmp/showdbscript.js; rm -f /tmp/showdbscript.js";
echo "sleep 10" >>  /tmp/execute.sh;
echo "sudo sh /tmp/ssh_ncb.sh $primHOST $primUSER $primPWD "'"'$script2';"' >> /tmp/execute.sh;

chmod 777 /tmp/execute.sh;
chmod 777 /tmp/initiaterepl1.js;
chmod 777 /tmp/initiaterepl2.js;
chmod 777 /tmp/initiaterepl3.js;
chmod 777 /tmp/showdbscript.js;

sudo sh /tmp/execute.sh;
rm -f /tmp/execute.sh;
echo "************** getservers.sh end ********************" ;

