echo "************** ssh_ncb.sh start ********************";
server=$1;
user=$2;
pwd=$3;
script=$4;
echo "*** ssh on server $server ***";
echo "sudo sshpass -p $pwd ssh -o StrictHostKeyChecking=no $user@$server $script;";
sudo sshpass -p $pwd ssh -o StrictHostKeyChecking=no $user@$server $script;
echo "************** ssh_ncb.sh end ********************";
