echo "************** configdb.sh start ********************";
server=$1;
preserver=$2;
preuser=$3; 
prepwd=$4;

if [ ! -f /var/lib/mongokey ]
  then
    sudo mkdir /var/lib/mongokey;
   if [ ! -z "$preserver" ]
     then
     echo "******************Copy key File***************";
     sudo sshpass -p $prepwd scp -o StrictHostKeyChecking=no $preuser@$preserver:/var/lib/mongokey/key /var/lib/mongokey;
   else
     echo "************************Creating key file***************************";
     sudo touch /var/lib/mongokey/key;
     sudo openssl rand -base64 756 > /var/lib/mongokey/key;
     sudo chmod 400 /var/lib/mongokey/key;
   fi;
fi;
if [ ! -f /var/lib/mongo ]
  then
    sudo mkdir /var/lib/mongo;
fi;
if [ ! -f /var/log/mongodb ]
  then
    sudo mkdir /var/log/mongodb;
fi;

echo "************** configdb.sh end ********************";
