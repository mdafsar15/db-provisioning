serverid=$1;
serverip=$2;
HOST=$3;
if [ ! -f  /etc/mysql/my.cnf ]
  then
    touch /etc/mysql/my.cnf;
else
   mv /etc/mysql/my.cnf /etc/mysql/my_bkp.cnf
fi;
echo "[mysqld]" >> /etc/mysql/my.cnf;
echo "bind-address	= 0.0.0.0" >> /etc/mysql/my.cnf;
echo "server-id	= "$serverid >> /etc/mysql/my.cnf;
echo "log-bin		= /var/log/mysql/mysql-in.log" >> /etc/mysql/my.cnf;
if [ "$serverid" != "1" ]
  then
    echo "relay-log	= /var/log/mysql/mysql-relay-bin.log" >> /etc/mysql/my.cnf;
fi;
sudo systemctl start mysql;
sudo mysql -ANe "CREATE USER 'aduser'@'%' IDENTIFIED BY 'aduser';";
sudo mysql -ANe "GRANT ALL PRIVILEGES ON *.* TO 'aduser'@'%' WITH GRANT OPTION;";
sudo mysql -u aduser -paduser -ANe "ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Welcome@123';";
if [ "$serverid" != "1" ]
  then
    sudo mysql -u aduser -paduser -h $serverip -ANe "CREATE USER 'slave_user'@'$HOST' IDENTIFIED BY 'Welcome@123';"
    sudo mysql -u aduser -paduser -h $serverip -ANe "GRANT REPLICATION SLAVE ON *.* TO 'slave_user'@'$HOST';";
    sudo mysql -u aduser -paduser -h $serverip -ANe "ALTER USER 'slave_user'@'$HOST' IDENTIFIED WITH mysql_native_password BY 'Welcome@123';";
    SMS=/tmp/show_master_status.txt
    sudo mysql -u aduser -paduser -h $serverip -ANe "SHOW MASTER STATUS" > ${SMS}
    CURRENT_LOG=`cat ${SMS} | awk '{print $1}'`
    CURRENT_POS=`cat ${SMS} | awk '{print $2}'`
    echo ${CURRENT_LOG} ${CURRENT_POS};
    echo "change master to master_host='$serverip', master_user='slave_user', master_password='Welcome@123', master_log_file='${CURRENT_LOG}', master_log_pos=${CURRENT_POS};"
    sudo mysql -u aduser -paduser -ANe "change master to master_host='$serverip', master_user='slave_user', master_password='Welcome@123', master_log_file='${CURRENT_LOG}', master_log_pos=${CURRENT_POS};"
    sudo systemctl restart mysql;
    sudo mysql -u aduser -paduser -h $serverip -ANe "SHOW DATABASES";
fi;
