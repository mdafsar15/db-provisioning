echo "************** installdb.sh start ********************";
if [ ! -f /usr/bin/mysql ]
    then
        echo "****** Installing Mysql DB *****";
        sudo apt-get update;
	sudo apt install -y mysql-server;
        sudo systemctl status mysql;
	sudo systemctl stop mysql;
else
  echo "Mysql DB already installed.  Skipping...";
fi
echo "************** installdb.sh end ********************";
