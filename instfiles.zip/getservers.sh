echo "************** getservers.sh start ********************";
sudo rm -f /tmp/execute.sh;
sudo apt-get update -y;
sudo apt-get install -y sshpass;
serverid=1;
echo "***start***";
while read HOST USER PWD;
  do echo $HOST;
  if [ ! -z "$HOST" ]
    then
    if [ "$serverid" = "1" ]
      then
        masterserver=$HOST;
    fi;
    script11='"chmod 777 /tmp/uninstalldb.sh; sh /tmp/uninstalldb.sh mysql;"';
    echo "sudo sh /tmp/scp_ncb.sh $HOST $USER $PWD uninstalldb.sh;" >> /tmp/execute.sh;
    echo "sudo sh /tmp/ssh_ncb.sh $HOST $USER $PWD $script11;" >> /tmp/execute.sh;
    
    script1='"chmod 777 /tmp/installdb.sh; sh /tmp/installdb.sh;"';
    echo "sudo sh /tmp/scp_ncb.sh $HOST $USER $PWD installdb.sh;" >> /tmp/execute.sh;
    echo "sudo sh /tmp/ssh_ncb.sh $HOST $USER $PWD $script1;" >> /tmp/execute.sh;
    script2="chmod 777 /tmp/configdb.sh; sh /tmp/configdb.sh";
    echo "sudo sh /tmp/scp_ncb.sh $HOST $USER $PWD configdb.sh;" >> /tmp/execute.sh;
    echo "sudo sh /tmp/ssh_ncb.sh $HOST $USER $PWD " '"'$script2 $serverid $masterserver $HOST';"' >> /tmp/execute.sh;
    serverid=$(( $serverid + 1 ));
  fi;
  echo "$HOST Completed";
done < /tmp/servers_mysql.txt

sh /tmp/execute.sh;
